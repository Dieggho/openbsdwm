#!/bin/sh
xcompmgr &
slstatus &
/home/void/.fehbg &