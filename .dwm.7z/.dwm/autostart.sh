#!/bin/sh
xcompmgr &
slstatus &
/home/void/.fehbg &
doas sysctl hw.smt=1 &
