/* See LICENSE file for copyright and license details. */


#include "push.c"

/* appearance */
static const unsigned int borderpx  = 3;        /* border pixel of windows */
static const unsigned int snap      = 16;       /* snap pixel */
static const int showbar            = 1;        /* 0 means no bar */
static const int topbar             = 1;        /* 0 means bottom bar */
static const int focusonwheel       = 1;
static const char buttonbar[]       = "        ";
static const char *fonts[]          = { "Sans:size=8" };
static const char dmenufont[]       = "Sans:size=8";
static const char col_gray1[]       = "#181811";
static const char col_gray2[]       = "#0e0e00";
static const char col_gray3[]       = "#111108";
static const char col_gray4[]       = "#dddddd";
static const char col_cyan[]        = "#deb92c";
static const char *colors[][3]      = {
	/*               fg         bg         border   */
	[SchemeNorm] = { col_gray4, col_gray1, col_gray3 },
	[SchemeSel]  = { col_cyan, col_gray2, col_gray2  },
};

/* tagging */
static const char *tags[] = { " Main", " Web", " Net", " Doc", " Term", " Media", " Desk" };

static const Rule rules[] = {
	/* xprop(1):
	 *	WM_CLASS(STRING) = instance, class
	 *	WM_NAME(STRING) = title
	 */
	/* class      			instance    title       tags mask     isfloating   monitor */
	{ "Pinta",     			NULL,       NULL,       1 << 5,       0,           -1 },
	{ "firefox",  			NULL,       NULL,       1 << 1,       0,           -1 },
	{ "Firefox",  			NULL,       NULL,       1 << 1,       0,           -1 },
	{ "Navigator", 			NULL,       NULL,       1 << 1,       0,           -1 },
	{ "Google-chrome",		NULL,       NULL,       1 << 1,       0,           -1 },
        { "mupen64plus",                NULL,       NULL,       1 << 5,       0,           -1 },
        { "retroarch",                  NULL,       NULL,       1 << 5,       0,           -1 },
	{ "Terminal",     		NULL,       NULL,       1 << 4,       0,           -1 },
	{ "root-terminal",     		NULL,       NULL,       1 << 4,       0,           -1 },
	{ "sqlmap-shell",     		NULL,       NULL,       1 << 4,       0,           -1 },
	{ "Deadbeef",  			NULL,       NULL,       1 << 0,       0,           -1 },
	{ "Tor Browser",                NULL,       NULL,       1 << 2,       0,           -1 },
        { "Transmission",               NULL,       NULL,       1 << 2,       0,           -1 },
	{ "Leafpad",  			NULL,       NULL,       1 << 3,       0,           -1 },
	{ "Epdfview",  			NULL,       NULL,       1 << 3,       0,           -1 },
	{ "ffplay",  			NULL,       NULL,       1 << 5,       0,           -1 },
	{ "Gimp", 			NULL,       NULL,       1 << 5,       0,           -1 },
	{ "gimp", 			NULL,       NULL,       1 << 5,       0,           -1 },
	{ "qemu-system-x86_64",		NULL,       NULL,       1 << 5,       0,           -1 },
	{ "Qemu-system-x86_64",		NULL,       NULL,       1 << 5,       0,           -1 },
	{ "mednafen",  			NULL,       NULL,       1 << 5,       0,           -1 },
	{ "feh",  			NULL,       NULL,       1 << 5,       0,           -1 },
	{ "Sxiv",                       NULL,       NULL,       1 << 5,       1,           -1 },
	{ "Xephyr",     		NULL,       NULL,       1 << 6,       0,           -1 },
	{ "qt5ct",  			NULL,       NULL,       1 << 6,       1,           -1 },
	{ "Lxappearance",		NULL,       NULL,       1 << 6,       1,           -1 },
        { "Lxtask",			NULL,       NULL,       0 << 0,       1,           -1 },
        { "SmartTerm",                  NULL,       NULL,       0 << 0,       1,           -1 },
        { "ROX-Filer",                  NULL,       NULL,       0 << 0,       0,           -1 },
        { "dosbox",                     NULL,       NULL,       1 << 5,       0,           -1 },
};

/* layout(s) */
static const float mfact     = 0.50; /* factor of master area size [0.05..0.95] */
static const int nmaster     = 1;    /* number of clients in master area */
static const int resizehints = 0;    /* 1 means respect size hints in tiled resizals */


static const Layout layouts[] = {
	/* symbol      arrange function */
	{ "Tile",      tile },              /* first entry is default */
	{ "Float",     NULL },    	    /* no layout function means floating behavior */
	{ "Monocle",   monocle },
};


void
setlayoutex(const Arg *arg)
{
	setlayout(&((Arg) { .v = &layouts[arg->i] }));
}

void
viewex(const Arg *arg)
{
	view(&((Arg) { .ui = 1 << arg->ui }));
}

void
viewall(const Arg *arg)
{
	view(&((Arg){.ui = ~0}));
}

void
toggleviewex(const Arg *arg)
{
	toggleview(&((Arg) { .ui = 1 << arg->ui }));
}

void
tagex(const Arg *arg)
{
	tag(&((Arg) { .ui = 1 << arg->ui }));
}

void
toggletagex(const Arg *arg)
{
	toggletag(&((Arg) { .ui = 1 << arg->ui }));
}

void
tagall(const Arg *arg)
{
	tag(&((Arg){.ui = ~0}));
}

/* signal definitions */
/* signum must be greater than 0 */
/* trigger signals using `xsetroot -name "fsignal:<signame> [<type> <value>]"` */
static Signal signals[] = {
	/* signum           function */
	{ "focusstack",     focusstack },
	{ "setmfact",       setmfact },
	{ "togglebar",      togglebar },
	{ "incnmaster",     incnmaster },
	{ "togglefloating", togglefloating },
	{ "focusmon",       focusmon },
	{ "tagmon",         tagmon },
	{ "zoom",           zoom },
	{ "view",           view },
	{ "viewall",        viewall },
	{ "viewex",         viewex },
	{ "toggleview",     view },
	{ "toggleviewex",   toggleviewex },
	{ "tag",            tag },
	{ "tagall",         tagall },
	{ "tagex",          tagex },
	{ "toggletag",      tag },
	{ "toggletagex",    toggletagex },
	{ "killclient",     killclient },
	{ "quit",           quit },
	{ "setlayout",      setlayout },
	{ "setlayoutex",    setlayoutex },
};

/* key definitions */
#define XF86MonBrightnessDown			0x1008ff03
#define XF86MonBrightnessUp			0x1008ff02
#define XF86AudioMute				0x1008ff12
#define XF86AudioLowerVolume			0x1008ff11
#define XF86AudioRaiseVolume			0x1008ff13
#define MODKEY Mod4Mask
#define TAGKEYS(KEY,TAG) \
	{ MODKEY,                       KEY,      view,           {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask,           KEY,      toggleview,     {.ui = 1 << TAG} }, \
	{ MODKEY|ShiftMask,             KEY,      tag,            {.ui = 1 << TAG} }, \
	{ MODKEY|ControlMask|ShiftMask, KEY,      toggletag,      {.ui = 1 << TAG} },

/* helper for spawning shell commands in the pre dwm-5.0 fashion */
#define SHCMD(cmd) { .v = (const char*[]){ "/bin/sh", "-c", cmd, NULL } }

/* commands */
static char dmenumon[2] = "0";               /* component of dmenucmd, manipulated in spawn() */
static const char *dmenucmd[] =              { "dmenu_run", "-m", dmenumon, "-fn", dmenufont, "-nb", col_gray1, "-nf", col_gray4, "-sb", col_cyan, "-sf", col_gray4, "-p", "run", NULL };
static const char *termcmd[] =               { "/home/void/.sh/terminal", NULL }; /* change me to any terminal you want */
static const char *smrtermcmd[] =            { "st", "-c", "SmartTerm", "-e", "ksh", "-l", NULL };
static const char *xterm[] =                 { "xterm", NULL };
static const char *screenshot[] =            { "/home/void/.sh/screenshot", NULL };
static const char *wscrot[] =                { "/home/void/.sh/wscrot", NULL };
static const char *dwmenu[] =                { "/home/void/.sh/dwmenu", NULL };
static const char *sessmgr[] =               { "/home/void/.sh/session-manager", NULL }; 
static const char *mixer[] =                 { "/home/void/.sh/mixer", NULL };
static const char *layoutmenu[] =            { "/home/void/.sh/lmenu", NULL };
static const char *firefox[] =               { "firefox", NULL };
static const char *deadbeef[] =              { "deadbeef", NULL };
static const char *rox[] =                   { "rox", NULL };
static const char *bg[] =                    { "/home/void/.sh/wallpaper", NULL };

static Key keys[] = {
	/* modifier                     key        function        argument */
	//{ 0,                            XF86AudioMute,             spawn,          {.v = vmute } },
	//{ 0,                            XF86AudioRaiseVolume,      spawn,          {.v = vup } },
	//{ 0,                            XF86AudioLowerVolume,      spawn,          {.v = vdown } },
	{ 0,                            XK_Print,  spawn,          {.v = screenshot } },
	{ ShiftMask,                    XK_Print,  spawn,          {.v = wscrot } },
	{ MODKEY,                       XK_p,      spawn,          {.v = dmenucmd } },
	{ Mod5Mask,                     XK_p,      spawn,          {.v = dmenucmd } },
	{ Mod5Mask,                     XK_Return, spawn,          {.v = termcmd } },
	{ ControlMask|Mod1Mask,         XK_t,      spawn,          {.v = smrtermcmd } },
	{ MODKEY,                       XK_b,      togglebar,      {0} },
	{ MODKEY|ShiftMask,             XK_s,      pushdown,       {0} },
    	{ MODKEY|ShiftMask,             XK_w,      pushup,         {0} },
	{ MODKEY,                       XK_s,      focusstack,     {.i = +1 } },
	{ MODKEY,                       XK_w,      focusstack,     {.i = -1 } },
	{ MODKEY,                       XK_d,      setmfact,       {.f = +0.05} },
	{ MODKEY,                       XK_a,      setmfact,       {.f = -0.05} },
        { MODKEY|ShiftMask,             XK_d,      incnmaster,     {.i = -1 } },
        { MODKEY|ShiftMask,             XK_a,      incnmaster,     {.i = +1 } },
        { Mod5Mask,                     XK_space,  togglefloating, {0} },
        { MODKEY,                       XK_space,  togglefloating, {0} },
	{ Mod5Mask,                     XK_k,      killclient,     {0} },
	{ MODKEY,                       XK_c,      killclient,     {0} },
        { MODKEY,                       XK_Tab,    view,           {0} },
	{ MODKEY,                       XK_t,      setlayout,      {.v = &layouts[0]} },
	{ MODKEY,                       XK_f,      setlayout,      {.v = &layouts[1]} },
	{ MODKEY,                       XK_m,      setlayout,      {.v = &layouts[2]} },
	{ MODKEY,                       XK_space,  setlayout,      {0} },
	{ MODKEY|ShiftMask,             XK_space,  togglefloating, {0} },
	{ MODKEY|ShiftMask,             XK_f,      togglefullscr,  {0} },
	{ Mod5Mask,                     XK_comma,  focusmon,       {.i = -1 } },
	{ Mod5Mask,                     XK_period, focusmon,       {.i = +1 } },
	{ Mod5Mask|ShiftMask,           XK_comma,  tagmon,         {.i = -1 } },
	{ Mod5Mask|ShiftMask,           XK_period, tagmon,         {.i = +1 } },
	{ MODKEY,		        XK_z,      spawn,          {.v = dwmenu } },
	{ MODKEY,		        XK_x,      spawn,          {.v = xterm } },
	{ Mod5Mask,                     XK_f,      spawn,          {.v = firefox } },
	{ Mod5Mask,                     XK_d,      spawn,          {.v = deadbeef } },
	{ Mod5Mask,                     XK_r,      spawn,          {.v = rox } },
	{ Mod5Mask,                     XK_b,      spawn,          {.v = bg } },
	TAGKEYS(                        XK_1,                      0)
	TAGKEYS(                        XK_2,                      1)
	TAGKEYS(                        XK_3,                      2)
	TAGKEYS(                        XK_4,                      3)
	TAGKEYS(                        XK_5,                      4)
	TAGKEYS(                        XK_6,                      5)
	TAGKEYS(                        XK_7,                      6)
	{ MODKEY|ShiftMask,             XK_q,      quit,           {0} },
};

/* button definitions */
/* click can be ClkLtSymbol, ClkStatusText, ClkWinTitle, ClkClientWin, or ClkRootWin */
static Button buttons[] = {
	/* click                event mask      button          function        argument */
        { ClkButton,		0,		Button1,	spawn,		{.v = dwmenu } },
        { ClkButton,		0,		Button2,	spawn,		{.v = smrtermcmd } },
        { ClkButton,            0,              Button3,        spawn,          {.v = sessmgr } },
        { ClkButton,            0,              Button4,        incnmaster,     {.i = +1 } },
        { ClkButton,            0,              Button5,        incnmaster,     {.i = -1 } },
        { ClkLtSymbol,          0,              Button1,        spawn,          {.v = layoutmenu } },
	{ ClkLtSymbol,          0,              Button2,        setlayout,      {.v = &layouts[0]} },
	{ ClkLtSymbol,          0,              Button3,        togglefloating, {0} },
	{ ClkLtSymbol,          0,              Button4,        pushup,         {.i = -1 } },
	{ ClkLtSymbol,          0,              Button5,      	pushdown,       {.i = +1 } },
	{ ClkWinTitle,          0,              Button4,        focusstack,     {.i = -1 } },
        { ClkWinTitle,          0,              Button5,        focusstack,     {.i = +1 } },
        { ClkWinTitle,          0,              Button2,        killclient,     {0} },
	{ ClkWinTitle,          0,              Button1,	movemouse,      {0} },
        { ClkWinTitle,          0,              Button3,        resizemouse,    {0} },
        { ClkStatusText,        0,              Button1,        spawn,          {.v = mixer } },
	{ ClkStatusText,        0,              Button2,        spawn,          {.v = termcmd } },
        { ClkStatusText,        0,              Button3,        spawn,          {.v = mixer } },
	{ ClkClientWin,         Mod5Mask,       Button1,        movemouse,      {0} },
	{ ClkClientWin,         Mod5Mask,       Button2,        killclient,     {0} },
	{ ClkClientWin,         Mod5Mask,       Button3,        resizemouse,    {0} },
	{ ClkClientWin,         Mod5Mask,       Button4,        togglefloating, {0} },
	{ ClkClientWin,         Mod5Mask,       Button5,        togglefloating, {0} },
	{ ClkTagBar,            0,              Button1,        view,           {0} },
        { ClkTagBar,            0,              Button2,        toggletag,      {0} },
	{ ClkTagBar,            0,              Button3,        tag,            {0} },
	{ ClkTagBar,            MODKEY,         Button1,        tag,            {0} },
	{ ClkTagBar,            MODKEY,         Button3,        toggletag,      {0} },
        { ClkRootWin,           0,              Button1,        movemouse,      {0} },
        { ClkRootWin,           0,              Button3,        resizemouse,    {0} },
        { ClkRootWin,           0,              Button2,        killclient,     {0} },
        { ClkRootWin,           0,              Button4,        focusstack,     {.i = -1 } },
	{ ClkRootWin,           0,              Button5,        focusstack,     {.i = +1 } },
};
